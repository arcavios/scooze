# slurrk
API tools for interacting with MongoDB for Magic: the Gathering tournaments, decklists, and cards.
